﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Dbase
{
    class ConnectHelper
    {
        public static
       List<Man> man = new List<Man>();
        public static void ReadListFromFile(string filename)
        {
            StreamReader streamReader = new StreamReader(filename, Encoding.UTF8);
            while (!streamReader.EndOfStream)
            {
                string line = streamReader.ReadLine();
                string[] items = line.Split(';');
                Man mans = new Man()
                {
                    Name = items[0].Trim(),
                    Birth_year = int.Parse(items[1].Trim()),
                    Pay = double.Parse(items[2].Trim())
                };
                man.Add(mans);
            }
        }
    }
}
