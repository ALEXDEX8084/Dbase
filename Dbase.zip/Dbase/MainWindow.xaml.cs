﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;


namespace Dbase
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {

            InitializeComponent();
            {
                ConnectHelper.ReadListFromFile(@"dbase.txt");


                Worker.ItemsSource = ConnectHelper.man;
            }
            Man[] dbase = new Man[100]; int n = 0; try
                {
                    StreamReader f = new StreamReader("dbase.txt", Encoding.UTF8); //4
                    string s; int i = 0;
                    while ((s = f.ReadLine()) != null) // 5
                        dbase[i] = new Man(s); Console.WriteLine(dbase[i]); ++i;
                    n = i - 1;
                    f.Close();
                }
                catch (FileNotFoundException e)
                {
                    Console.WriteLine(e.Message); Console.WriteLine(" Проверьте правильность имени файла!"); return;
                }
                catch (IndexOutOfRangeException)
                { Console.WriteLine("Слишком большой файл!"); return; }
                catch (FormatException)
                { Console.WriteLine("Недопустимая дата рождения или оклад"); return; }
                catch (Exception e)
                { Console.WriteLine("Өшибка: " + e.Message); return; }
                int n_man = 0; double mean_pay = 0;
                Console.WriteLine("Введите фамилию сотрудника");
                string name; while ((name = Console.ReadLine()) != "")
                {
                    bool not_found = true;
                    for (int k = 0; k <= n; ++k)
                    {
                        Man man = dbase[k];
                        if (man.Compare(name) == 0)
                        {
                            Console.WriteLine(man); ++n_man; mean_pay += man.Pay; not_found = false;
                        }
                    }
                    if (not_found) Console.WriteLine("Такого сотрудника нет");
                    Console.WriteLine("Введите фамилию сотрудника или Enter для окончания");
                }
                if (n_man > 0)
                {
                    mean_pay = mean_pay / n_man;
                    Console.WriteLine("Средний оклад: {0:F2}", mean_pay);
                }
            }

        private void Upper_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Lower_Click(object sender, RoutedEventArgs e)
        {

        }
        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            Worker.ItemsSource = ConnectHelper.man.ToList();
            Worker.SelectedIndex = -1;

        }

        private void Average_Click(object sender, RoutedEventArgs e)
        {
            var count = ConnectHelper.man.Select(x => x.Pay).Count();
            var sum = ConnectHelper.man.Select(p => p.Pay).Sum();
            Avg.Text ="Средний оклад: " + $"{sum/count}";

        }
        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            Worker.ItemsSource = ConnectHelper.man.Where(x => x.Name.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }
    }
}

        